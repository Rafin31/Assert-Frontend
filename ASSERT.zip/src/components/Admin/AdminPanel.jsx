import React from 'react'
import QueryApproval from './QueryApproval'

const AdminPanel = () => {
  return (
    <div>
        <QueryApproval/>
    </div>
  )
}

export default AdminPanel;
