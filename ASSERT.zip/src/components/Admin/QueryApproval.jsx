import React from 'react'

const QueryApproval = () => {
  return (
    <div>QueryApproval</div>
  )
}

export default QueryApproval;
