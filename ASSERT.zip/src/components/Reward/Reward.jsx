import React from 'react'


const Reward = () => {
  return (
    <div>
      <div>
        Reward
      </div>
        
        
        
    </div>
  )
}

export default Reward;