import React from 'react'

export default function CreateIssue() {
    return (
        <div>CreateIssue</div>
    )
}
