import React from 'react'

export default function MyPredictions() {
    return (
        <div>MyPredictions</div>
    )
}
