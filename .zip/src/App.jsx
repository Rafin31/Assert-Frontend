import './App.css'
import AppRouter from './routes'


function App() {

  return (
    <div data-theme="sunset" className="bg-navy">
      <AppRouter />
    </div>

  )
}

export default App
